const game = require("../game");
const pick = require("../utils/pick");

module.exports = async (msg) => {
    if (game.players.length < 3) {
        return msg.reply("Need at least 3 players to start the game.");
    }

    if (game.words.length < 2) {
        return msg.reply("Words have not been set. Use !set first.");
    }

    game.started = true;

    const chosenWord = pick(game.words);
    const impostorPlayerId = pick(game.players);

    for (const id of game.players) {
        const user = await msg.client.users.fetch(id);

        if (id === impostorPlayerId) {
            await user.send(`🔥 You are the IMPOSTER!`);
        } else {
            await user.send(`Your word is: **${chosenWord}**`);
        }
    }

    msg.channel.send("Game started! One among you is the imposter…");
};
