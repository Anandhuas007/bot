const game = require("../game");

module.exports = (msg) => {
    game.reset();
    msg.reply("Game reset. Players can join again.");
};
