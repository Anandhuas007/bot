const game = require("../game");

module.exports = (msg) => {

    if (!game.players.includes(msg.author.id)) {
        return msg.reply("You are not in the game.");
    }

    // Remove the player
    game.players = game.players.filter(id => id !== msg.author.id);

    msg.reply("You left the game.");
};
