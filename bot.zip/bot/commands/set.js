const game = require("../game");

module.exports = (msg, args) => {
    if (args.length < 2) {
        return msg.reply("You need to provide at least 2 words.");
    }

    game.words = args;
    msg.reply(`Words set: ${game.words.join(", ")}`);
};
