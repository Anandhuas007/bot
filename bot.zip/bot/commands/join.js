const game = require("../game");

module.exports = (msg) => {
    if (game.started) {
        return msg.reply("Game already started. You can't join now.");
    }

    if (!game.players.includes(msg.author.id)) {
        game.players.push(msg.author.id);
        return msg.reply(`${msg.author.username} joined the game!`);
    }

    msg.reply("You are already in the game.");
};
