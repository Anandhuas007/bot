module.exports = {
    players: [],
    words: [],
    started: false,

    reset() {
        this.players = [];
        this.words = [];
        this.started = false;
    }
};
